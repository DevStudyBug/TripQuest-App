export interface AuthResponse {
  token: string | null;
  role: string | null;
  message: string;
}
