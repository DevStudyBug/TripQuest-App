export const environment = {
  production: true,
  apiBaseUrl: 'https://your-production-api-url.com/api/v1'
};
